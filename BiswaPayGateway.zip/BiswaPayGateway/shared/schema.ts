// Payment plans are defined in shared/payment-plans.ts
// This file is kept for reference but no database models are needed
