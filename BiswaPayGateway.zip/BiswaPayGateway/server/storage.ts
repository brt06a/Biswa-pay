import { randomUUID } from "crypto";

export interface IStorage {
  // Storage interface for future use
}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
